/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package herenciaclase;

// Superclase Formas
class Formas {
    // Método para dibujar la forma
    public void dibujar() {
        System.out.println("Dibujando una forma genérica");
    }
}

// Subclase Círculo
class Circulo extends Formas {
    // Método para dibujar un círculo
    @Override
    public void dibujar() {
        System.out.println("Dibujando un círculo");
    }
}

// Subclase Triángulo
class Triangulo extends Formas {
    // Método para dibujar un triángulo
    @Override
    public void dibujar() {
        System.out.println("Dibujando un triángulo");
    }
}

// Subclase Cuadrado
class Cuadrado extends Formas {
    // Método para dibujar un cuadrado
    @Override
    public void dibujar() {
        System.out.println("Dibujando un cuadrado");
    }
}

// Subclase Rectángulo
class Rectangulo extends Formas {
    // Método para dibujar un rectángulo
    @Override
    public void dibujar() {
        System.out.println("Dibujando un rectángulo");
    }
}

public class Herenciaclase {
    public static void main(String[] args) {
        // Crear instancias de las formas
        Formas forma1 = new Circulo();
        Formas forma2 = new Triangulo();
        Formas forma3 = new Cuadrado();
        Formas forma4 = new Rectangulo();

        // Llamar al método dibujar de cada forma
        forma1.dibujar();
        forma2.dibujar();
        forma3.dibujar();
        forma4.dibujar();
    }
}
